#include <stdio.h>

int main(int argc, char **argv) {

	//For 12 iterations, print a message along with line number
	for (int i = 1; i < 13; i++) {
		printf("#%d: ECE471 is a pretty radical course\n", i);
	}

	// printf("Hello world!\n");

	return 0;
}
