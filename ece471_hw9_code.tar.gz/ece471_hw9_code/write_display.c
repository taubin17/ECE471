#include <stdio.h>


int init_display(void) {
	return 0;
}

int write_display(int fd, double value) {

	return 0;
}



int shutdown_display(int fd) {

	return 0;

}
