#include <stdio.h>


double read_temp(void) {

	return 0.0;
}
