#include <stdio.h>

#include "read_temp.h"
#include "write_display.h"

int main(int argc, char **argv) {

	return 0;
}

