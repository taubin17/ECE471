int init_display(void);
int write_display(int fd,double value);
int shutdown_display(int fd);
