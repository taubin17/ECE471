/* returns temperature in degrees C */
double read_temp(void);
